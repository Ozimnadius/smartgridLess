var smartgrid = require('smart-grid');

smartgrid('./src/less', {
    columns: 24,
    offset: "10px",
    container: {
        maxWidth: "960px"
    },
    breakPoints: {
        md: {
            width: "992px",
            fields: "15px"
        },
        sm: {
            width: "720px",
            fields: "15px"
        },
        xs: {
            width: "576px",
            fields: "15px"
        },
        xxs: {
            width: "400px",
            fields: "5px"
        }
    },
    mixinNames: {
        
    },
    properties: [
        "justify-content",
        "align-items",
        "align-content",
        "align-self",
        "order",
        "flex",
        "flex-grow",
        "flex-shrink",
        "flex-basis",
        "flex-direction",
        "flex-wrap",
        "flex-flow",
        "float",
        "display"
    ]
});