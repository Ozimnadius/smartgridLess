var smartgrid = require('smart-grid');

smartgrid('./src/less', {
    columns: 24,
    offset: "10px",
    container: {
        maxWidth: "960px"
    },
    breakPoints: {
        lg: {
            width: "1200px",
            fields: "30px"
        },
        md: {
            width: "992px",
            fields: "15px"
        },
        sm: {
            width: "720px",
            fields: "15px"
        },
        xs: {
            width: "576px",
            fields: "15px"
        },
        xxs: {
            width: "400px",
            fields: "15px"
        }
    }
});